Creating a simple typing trainer
